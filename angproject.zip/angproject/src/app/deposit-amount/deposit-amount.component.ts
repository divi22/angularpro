import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-deposit-ammount',
  templateUrl: './deposit-amount.component.html',
  styleUrls: ['./deposit-amount.component.css']
})
export class DepositAmountComponent implements OnInit {

  user: User = new User();
  submitted = false;
  result : any;
  fresult : any;
  constructor(private router: Router, private userService: UserService) {}

  ngOnInit() {
  }

  depositAmount(): void {
    this.userService.depositAmount(this.user).subscribe(data=>{
      this.result = data;
      console.log(this.result);
      if(this.result == null){
        this.fresult = "Deposite Failed:Check Credenntials";
      }
      else{
        this.fresult = "Deposite successful";
      }
    });
  };

  onSubmit() {
    this.submitted = true;
    this.depositAmount();
  }
}
