import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {

  user: User = new User();
  submitted = false;
  result : any[];
  constructor(private router: Router, private userService: UserService) {}

  ngOnInit() {
  }

  printTransaction(): void {
    this.userService.printTransaction(this.user).subscribe(data=>{
      this.result = data;
      console.log(this.result);
    });
  };

  onSubmit() {
    this.submitted = true;
    this.printTransaction();
  }


}


