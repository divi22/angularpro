import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Router } from '../../../node_modules/@angular/router';
import { UserService } from '../user.service';
import { User } from '../user';

@Component({
  selector: 'app-showbalance',
  templateUrl: './showbalance.component.html',
  styleUrls: ['./showbalance.component.css']
})
export class ShowbalanceComponent implements OnInit {

  user: User = new User();
  submitted = false;
  result : any;
  constructor(private router: Router, private userService: UserService) {}

  ngOnInit() {
  }

  showBalance(): void {
    this.userService.showBalance(this.user).subscribe(data=>{
      this.result = data;
      console.log(this.result);
    });
  };

  onSubmit() {
    this.submitted = true;
    this.showBalance();
  }

}
