export class Transaction {
    transactionId  : any;
    transactionType : string;
    destAccountNo : any;
    transactionDate : any;
    amount : any;
    accountNo : any;
}
