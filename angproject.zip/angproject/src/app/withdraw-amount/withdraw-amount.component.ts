import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-withdraw-amount',
  templateUrl: './withdraw-amount.component.html',
  styleUrls: ['./withdraw-amount.component.css']
})
export class WithdrawAmountComponent implements OnInit {

  user: User = new User();
  submitted = false;
  result : any;
  fresult : any;
  constructor(private router: Router, private userService: UserService) {}

  ngOnInit() {
  }

  withdrawAmount(): void {
    this.userService.withdrawAmount(this.user).subscribe(data=>{
      this.result = data;
      console.log(this.result);
      if(this.result == null){
        this.fresult = "Withdraw Failed:Check Credenntials";
      }
      else{
        this.fresult = "Withdraw successful";
      }
    });
  };

  onSubmit() {
    this.submitted = true;
    this.withdrawAmount();
  }

}
